# 蝶语 Butterfly · AiKlog 博客主题

> 主题 id：`butterfly`　版本：**1.0.0**　形态：**源码模块（形态 A，需构建）** + **外置 SSR 主题（形态 B）**
> 设计参照：`hexo-theme-butterfly`（卡片式双栏博客主题）的设计语言，按《AiKlog 博客主题开发规范（第三方完整交付版）》v1.2 重新实现。

---

## 1. 这套主题是什么

一句话：**卡片式双栏博客** —— 半透明毛玻璃顶栏、白卡片列表（左右交替）、侧栏卡片组、右下悬浮按钮组、主色渐变页脚，并自带夜间模式。

与上游 Butterfly 的对应关系与三处**主动取舍**：

| 上游 Butterfly | 本主题 | 原因 |
|---|---|---|
| 全宽首屏 Banner（大标题 + 打字机副标 + 下滑箭头） | **去掉**，直接从内容区开始 | 按需求要求不做首屏大图页 |
| 文章卡片带封面图 | **纯 CSS 渐变装饰块**（色相按分类稳定派生） | AiKlog 数据契约**不含封面图字段**，不允许臆造 |
| 文章页全宽封面式标题栏 | 紧凑型文章头部卡（主色顶条 + 标题 + 元信息） | 同上，且与"不做首屏页"保持一致 |
| Font Awesome / CDN 图标与字体 | **全部内联 SVG + 系统字体栈** | 零外部依赖，离线可用、无 CSP 负担 |
| 侧栏「标签云」 | 保留组件，但**恒空时整卡隐藏** | 系统层标签数据尚未实现（规范 §4.6） |

其余标志性特征**全部保留**：毛玻璃顶栏的"向下滚动收起、向上滚动回落"、菜单项主色圆角悬停、卡片悬停上浮 + 封面纹样缩放 + 中央浮出「阅读」圆钮、侧栏作者卡与计数、右下角滚动进度环、主色渐变 + 波浪页脚、**夜间模式**。

---

## 2. 交付清单

```
butterfly-theme-1.0.0/
├─ README.md                              ← 本文件
├─ web/src/themes/butterfly/              ← 形态 A：SPA 源码模块（16 文件）
│   ├─ manifest.js                        主题元数据（id/title/tokens/entries…）
│   ├─ index.js                           注册入口（模块加载即 registerTheme）+ 合并 entries.post
│   ├─ helpers.js                         派生层（标题/分类/日期/摘要/排序/夜间偏好）
│   ├─ ButterflyView.vue                  列表页（列表 / 归档 / 检索 三视图 + 分类筛选 + 分页）
│   ├─ ButterflyHead.vue                  顶栏（毛玻璃 + 滚动收起 + 菜单 + 夜间切换）
│   ├─ ButterflyFoot.vue                  页脚（渐变 + 波浪）
│   ├─ ButterflyCard.vue                  文章卡片（左右交替）
│   ├─ ButterflySide.vue                  侧栏卡片组（作者卡/公告/最新更新/分类/标签云/站点信息）
│   ├─ ButterflyRight.vue                 右下悬浮按钮组（进度环 + 回顶 + 夜间 + 目录）
│   ├─ ButterflyPostView.vue              文章页（目录/版权卡/上下篇/相关阅读/评论槽）
│   ├─ ButterflyCatView.vue               分类页
│   ├─ ButterflyAuthorView.vue            作者页
│   ├─ ButterflyArchiveView.vue           归档页
│   ├─ ButterflySearchView.vue            搜索页
│   ├─ style.css                          列表 + 共享原子（构建期加 `.th-butterfly` 作用域）
│   └─ post.css                           文章页专属（构建期加 `.th-butterfly.th-view-post` 作用域）
├─ server/data/themes/butterfly/          ← 形态 B：外置 SSR 主题（2 文件）
│   ├─ ssr.css                            公网静态页 `/blog`、`/blog/{slug}`、`/{slug}` 样式
│   └─ manifest.json                      { title, version }
├─ design/                                设计对照（可离线双击打开）
│   ├─ index.html                         列表页静态预览
│   ├─ post.html                          文章页静态预览
│   ├─ theme.css                          style.css + post.css 原样拼接（仅供预览）
│   ├─ 对照-列表-桌面-1440.png
│   ├─ 对照-列表-移动-390.png
│   └─ 对照-文章-桌面-1440.png
└─ tools/theme-lint.sh                    交付前机械自检脚本（规范 §9.3 第 8 项交付物）
```

---

## 3. 安装步骤（2 处，规范 v1.2 起不再是 3 处）

### 3.1 形态 A（SPA 交互版，需构建）

1. 把 `web/src/themes/butterfly/` 整个目录复制进项目同名路径。
2. 在 **`web/src/themes/all.js`** 追加一行副作用导入：
   ```js
   import '@/themes/butterfly' // 注册蝶语主题（卡片式双栏 + 侧栏卡片组 + 夜间模式）
   ```
   > 注意：注册表是 `all.js`（列表页与文章页共用），**不要**再往 `BlogView.vue` 顶部散加 import。
3. 构建并重启：
   ```bash
   cd web && npm run build
   cd ../server && go build && pkill -x aiklog && ./aiklog run   # 部署机执行
   ```

### 3.2 形态 B（外置 SSR 主题，免编译）

把 `server/data/themes/butterfly/` 两个文件投放到部署机：

```bash
/opt/aiklog/data/themes/butterfly/ssr.css
/opt/aiklog/data/themes/butterfly/manifest.json
```

投放即生效（运行时按 mtime 缓存读取，**免编译、免重启**），并自动出现在博客主题下拉里。

### 3.3 关于 `settings.go` 白名单

**不需要修改。** 现行校验逻辑是「`builtinThemes` ∪ `data/themes/<id>` 目录存在」（`server/internal/handler/settings.go`），外置主题投放后即可在后台切换。

### 3.4 启用

- 后台站点设置里选择「蝶语 Butterfly」，或
- 直接预览：`/blog?theme=butterfly`（免登录）、`/app#/blog?view=public`（SPA）

---

## 4. 契约遵循（逐条对照规范 §2 / §3 / §4 / §5）

| 规范要求 | 本主题实现 |
|---|---|
| 数据只从 `inject('themeContext')` 取 | 全部组件通过 `useBlog()` 读取，兼容 ref 与普通对象两种包装 |
| 只用契约字段 | 仅用 `token / path / preview / file.{name,slug,updated_at,size}`；`file.author` 走可选链降级 |
| **禁止臆造** `views / cover / created_at` 等 | 零命中（自检第 5 项通过）；卡片封面位为**纯 CSS 装饰块**，不伪装成封面图 |
| 标题派生兼容 `.md` / `.markdown` | `postTitle()` 统一处理 |
| 分类 = `path` 首段 | `postCat()` / `catName()`，无 `/` 时显示「未分类」 |
| 日期取 `file.updated_at` | `postDate()`，兼容毫秒 / 秒级 / 字符串 |
| 文章链接一律 `ctx.postUrl()` | **不做 SPA 文章视图、不手拼 `#/p/`**（自检第 3 项无 `href="#"`） |
| **不重排 posts** | 默认严格保持系统下发顺序；仅当读者显式点「最新更新 / 标题」才排序 |
| 标签云 `v-if="tags.length"` + 非链接 `<span>` | 已按此实现，标签恒空时整卡隐藏 |
| 三态齐全（loading / error / 空态） | 列表、归档、检索、内页均为三态；骨架屏用 shimmer 动画 |
| 站名用 `<div>/<span>` 不用 `<h1>` | 顶栏站名为 `<span class="bf-site-name">`；`<h1>` 只用在页面标题 |
| 页头渲染 `<ThemeSwitch />` + 声明 `ui.themeSwitcher` | 顶栏右侧内联渲染，已在 manifest 声明 `ui:{themeSwitcher:true}` |
| 内页参数 `ctx.page.*` + hash 回退 | `readPageParam(ctx, [...], patterns)`，**不自行改 `location.hash`** |
| 锚点一律 `button + scrollIntoView` | 目录、回顶、分类筛选、分页全为 `button`；**零 `href="#xxx"`**（含 `:href="'#'+x"` 写法） |
| 令牌统一 `--th-*` 前缀 | 23 个令牌，全部 `--th-*`（清单见 §5） |
| 全部选择器挂前缀 | `bf-` 前缀，`style.css` / `post.css` 由构建插件自动加视图作用域 |
| 视图隔离（§0.4 新增） | 文章页专属样式全在 `post.css`；**文章视图根是 `.bf-post` 而非 `.bf-root`，故 post.css 自带 reset 四件套** |
| 移动端断点 | 1024 / 900 / 640 三档 |
| 无「热门/热榜/排行/精选」臆造文案 | 侧栏标题为「最新更新」「同类文章」「相关阅读」；**无任何榜单配色与名次高亮** |

### 外部依赖核对

主题只引用两个宿主已有端点，均已在 `server/internal/handler/routes.go` 注册：

- `/api/v1/blog/feed.xml` → 顶栏 / 页脚 / 侧栏的 RSS 入口
- 评论区使用宿主插件槽 `<BlogPluginSlot mount="post_bottom" />`，不自建评论

---

## 5. 设计令牌表

全部令牌定义在 `style.css` 的 `:root` 块（构建后被作用域化为 `.th-butterfly`，列表页与文章页共同继承）。

| 令牌 | 值 | 用途 |
|---|---|---|
| `--th-sky` | `#49b1f5` | 主色（与上游 Butterfly 默认主题色一致） |
| `--th-sky-deep` | `#2b8fd4` | 主色深阶（悬停 / 标题强调） |
| `--th-sky-soft` | `rgba(73,177,245,.12)` | 主色浅底（选中态 / 引用块底） |
| `--th-orange` | `#ff7242` | 悬停强调色（同上游 `--btn-hover-color`） |
| `--th-ink` | `#4c4948` | 正文（同上游 `--font-color`） |
| `--th-ink-head` | `#1f2d3d` | 标题与高亮文字（同上游 `--text-highlight-color`） |
| `--th-meta` | `#858585` | 次要信息（同上游 `--card-meta`） |
| `--th-quote` | `#6a737d` | 引用块文字（同上游 `--blockquote-color`） |
| `--th-card` | `#ffffff` | 卡片底色 |
| `--th-page` | `#f6f8fa` | 页面底色（同上游 `--sidebar-bg`） |
| `--th-line` | `#eeeeee` | 描边与分隔线（同上游 `--light-grey`） |
| `--th-line-2` | `#f0f0f0` | 更浅分隔线（表头 / tab） |
| `--th-dark-bg` | `#37474f` | 深色块与代码块（同上游 `--preloader-bg`） |
| `--th-shadow` | `0 3px 8px 6px rgba(7,17,27,.05)` | 卡片投影（同上游 `--card-box-shadow`） |
| `--th-shadow-hover` | `0 3px 8px 6px rgba(7,17,27,.09)` | 悬停投影（同上游 `--card-hover-box-shadow`） |
| `--th-r-sm` | `4px` | 小圆角 |
| `--th-r` | `8px` | 常规圆角 |
| `--th-r-lg` | `12px` | 大圆角（卡片） |
| `--th-font-d` | `'Titillium Web', 'PingFang SC', …` | 标题字体（上游正文字体栈，缺失时回落系统字体） |
| `--th-font-b` | `'PingFang SC', 'Microsoft YaHei', …` | 正文字体 |
| `--th-font-m` | `ui-monospace, …` | 等宽字体（编号 / 代码） |
| `--th-topbar-h` | `60px` | 顶栏高度（sticky 偏移基准） |
| `--th-aside-w` | `300px` | 侧栏宽度 |

### 夜间模式

主题自带夜间模式（**纯本地偏好**，写入 `localStorage['aiklog.butterfly.dark']`，不写站点设置、不影响其它主题）。
深色令牌在 `.bf-root.is-dark` / `.bf-post.is-dark` 处覆盖，仅作用于本主题子树：

卡片 `#1e2124` · 页面 `#121417` · 描边 `#2b2f35` · 正文 `#c9ccd4` · 标题 `#e8eaef`（主色保持 `#49b1f5`）

---

## 6. 自测记录（2026-09-16，本机实测）

### 6.1 规范机械自检

```
$ cd web/src/themes/butterfly && bash theme-lint.sh bf-
[1/6] 类名交叉比对            [OK] 悬空类无 · 死 CSS 无
[2/6] manifest.tokens 台账     [OK] 漏报无 · 虚报无
[3/6] hash 路由锚点            [OK] 无
[4/6] 高危文案词               [OK] 无
[5/6] 契约外字段               [OK] 无
[6/6] 文章页样式视图隔离        [OK] 声明 entries.post 且存在 post.css · style.css 无文章根选择器
== 结论 == 自动检查项全部通过
$ echo $?
0
```

### 6.2 构建

```
$ node node_modules/vite/bin/vite.js build --outDir <临时目录> --emptyOutDir false
✓ built in 5.20s          # 零错误、零警告（主题相关）
```

主题产物：

| chunk | 体积 |
|---|---|
| `ButterflyView` | 8.51 KB |
| `ButterflySide` | 8.83 KB |
| `ButterflyCard` | 1.98 KB |
| `ButterflyCatView` | 3.11 KB |
| `ButterflySearchView` | 3.55 KB |
| `ButterflyAuthorView` | 3.21 KB |
| `ButterflyArchiveView` | 2.86 KB |
| （入口 chunk 内含 PostView / Head / Foot / Right） | — |

### 6.3 视图作用域核验（关键回归项）

```
assets/index-*.css:
  .th-butterfly                    出现 360 次   ← style.css 已作用域化
  .th-butterfly.th-view-post       出现 121 次   ← post.css 已按文章视图隔离
  .th-butterfly.th-view-post .bf-copyright → 8 次
  裸 .bf-copyright（无视图前缀）           → 0 次   ← 列表页物理上拿不到文章样式
  令牌 --th-sky: #49b1f5                    ✓
```

### 6.4 注册核验

```
注册 chunk 内含 id "butterfly" ×2 与标题「蝶语 Butterfly」 ✓
内页 chunk 数：Butterfly(Cat|Author|Archive|Search)View = 4 ✓
文章页标记：bf-post-h1 / bf-copyright / bf-pn-card / bf-related-card / bf-post-toc-b / BlogPluginSlot 均在产物中 ✓
```

### 6.5 渲染核验

用 headless Chromium 对 `design/` 三张预览实际渲染并截图，均已肉眼确认：

- 列表页 1440：顶栏毛玻璃、视图条、筛选工具条、4 张交替卡片、分页、侧栏 5 张卡片、渐变页脚、右下悬浮组 —— 全部正常
- 列表页 390：卡片转纵向（装饰块变顶部横幅）、顶栏收起为纯图标、侧栏下移 —— 全部正常
- 文章页 1440：主色竖线标题、淡蓝引用块、深色代码块、表格、版权卡、上下篇、相关阅读网格、侧栏目录 —— 全部正常

---

## 7. 已知限制（如实记录，不掩盖）

1. **本机无 Go 工具链** —— `design/` 三张图是**主题静态预览**（用与主题完全相同的 CSS 渲染），**不是部署机上的运行截图**。部署机上按 §3 投完文件、构建重启后，用 `/blog?theme=butterfly`（SSR 轨）与 `/app#/blog?view=public`（SPA 轨）各截一张比对即可闭环。
2. **封面位是装饰块，不是图片** —— AiKlog 数据契约不含 cover 字段，主题不臆造。装饰块色相由分类名哈希稳定派生，仅作版面区分，不表达任何数据语义。
3. **侧栏标签云恒空** —— 系统层标签数据未实现（规范 §4.6）。组件按 `v-if="tags.length"` 写好，数据一到位即自动出现；标签为**非链接 `<span>`**，不做 `?tag=` 死链。
4. **作者页归集依赖 `file.author`** —— 该字段属系统侧待透出项（规范 §10-10）。主题做了降级：列表无 `file.author` 时按「单一作者站点」处理并在页头文案里如实说明，不虚构图示。
5. **夜间模式是主题自带的本地偏好** —— 与宿主/其它主题的深色机制不互通（宿主暂无统一深色开关）。这是有意为之：避免主题越权改动全局外观。
6. **上游已知断裂（系统侧，非主题缺陷）** —— `BlogView.vue` 的 `ctx.postUrl()` 目前优先返回 `/{slug}`（SSR 静态页），从 SPA 列表点文章会整页跳出 SPA。主题**坚持用 `ctx.postUrl(post)` 而不自行拼链接**，系统侧修好后全站自动生效。
7. **仓库改动未提交 git** —— 本仓有并行会话在改其它主题文件，按约定不碰。需要提交时只加两个精确路径：`web/src/themes/butterfly/` 与 `web/src/themes/all.js`。

---

## 8. 版本记录

### v1.0.0（2026-09-16）

- 首个完整版：列表页（列表 / 归档 / 检索 三视图 + 分类筛选 + 排序 + 分页 + 骨架屏）
- 文章页（紧凑头部卡 + 正文排版 + 版权卡 + 分享条 + 上下篇 + 相关阅读 + 侧栏目录 + 评论插件槽）
- 四个内页：分类 / 作者 / 归档 / 搜索
- 侧栏卡片组：作者卡（真实计数）/ 站点公告 / 最新更新 / 分类（可展开）/ 标签云（空则隐藏）/ 站点信息
- 顶栏毛玻璃 + 滚动上现下隐；右下悬浮组含滚动进度环；主色渐变 + 波浪页脚
- 主题自带夜间模式（本地偏好）
- SSR 外置样式 `ssr.css`，覆盖规范附录 A 全部类名
- `theme-lint.sh` 6 项全过（退出码 0）；`vite build` 零错误

---

## 9. 交付前请对方自查

```bash
cd web/src/themes/butterfly
bash theme-lint.sh bf-     # 期望：6 项全过，退出码 0
```

脚本盲区（命中 `[!]` 需人工确认）：动态拼接类名、`:class` 绑定类、`helpers.js` / `index.js` 中的类名不在静态扫描范围内。
