# 青野 Verdant · AiKlog 博客主题交付包

> 版本 **1.0.0** · 2026-09-16 · 依据《AiKlog 博客主题开发规范（第三方完整交付版）》**v1.2**
> 配套自检脚本 `tools/theme-lint.sh` · 配套设计稿 `design/design-verdant.html`

---

## 1. 一句话描述

明亮清爽的生活方式主题：暖白底 + 森林绿强调 + 薄荷辅助 + 有机圆角，适合生活、自然、产品、品牌类内容。含**列表页 + 文章页 + 分类 / 作者 / 归档 / 搜索四个内页**，并与 SSR 静态页（`/blog`、`/{slug}`）气质一致。

---

## 2. 交付清单（规范 §0.1 八项）

| # | 交付物 | 包内位置 | 说明 |
|---|---|---|---|
| 1 | `manifest.js` | `web/src/themes/verdant/` | 元数据 + 能力声明（`ui.themeSwitcher: true`） |
| 2 | `index.js` | 同上 | 模块加载即 `registerTheme`；合并 `entries.post` |
| 3 | `VerdantView.vue` | 同上 | 列表页入口（`entry`） |
| 4 | `style.css` | 同上 | 列表页 + 共享原子（构建插件自动加 `.th-verdant` 作用域） |
| 4b | `post.css` | 同上 | **文章页专属样式**（自动加 `.th-verdant.th-view-post` 作用域，零泄漏） |
| 5 | 内页组件 ×5 | 同上 | `VerdantPostView` / `CatView` / `AuthorView` / `ArchiveView` / `SearchView` |
| — | 公共组件 ×4 + 派生层 | 同上 | `VerdantHead` / `VerdantFoot` / `VerdantCard` / `VerdantSide` / `helpers.js` |
| 6 | `ssr.css` + `manifest.json` | `server/data/themes/verdant/` | 公网静态页换肤（**必修项**） |
| 7 | 设计稿对照 | `design/` | `design-verdant.html` + 桌面/移动对照图 |
| 8 | 自检报告 | 本文件 §6 | `theme-lint.sh` 运行输出与退出码 |

---

## 3. 安装与生效

### 3.1 形态 A：SPA 交互版（需构建）

```bash
# 1) 源码入库（覆盖同名目录）
cp -r web/src/themes/verdant   <AiKlog>/web/src/themes/

# 2) 注册（集中注册表，列表页与文章页共用）
#    在 <AiKlog>/web/src/themes/all.js 追加一行：
#    import '@/themes/verdant' // 注册青野主题（暖白 + 森林绿，明亮清爽）

# 3) 构建前端
cd <AiKlog>/web && npm run build

# 4) 产物嵌入 + 后端构建
rm -rf <AiKlog>/server/internal/handler/webdist && mkdir -p <AiKlog>/server/internal/handler/webdist
cp -r <AiKlog>/web/dist/* <AiKlog>/server/internal/handler/webdist/
cd <AiKlog>/server && go build -o bin/aiklog ./cmd/aikmap

# 5) 重启（换二进制前必须先 pkill，否则 Text file busy）
pkill -x aiklog; sleep 2
cd /opt/aiklog && setsid nohup ./bin/aiklog -addr 127.0.0.1:8780 -db data/aikmap.db > aiklog.log 2>&1 < /dev/null &
```

> 主题 id `verdant` 已进入 `web/src/themes/all.js`；`settings.go` 的 `blog.theme` 校验为「内置清单 ∪ `data/themes/` 目录存在」，因此**无需再改后端白名单**，只要 §3.2 的目录已投放。

### 3.2 形态 B：SSR 静态页（免编译，丢文件即生效）

```bash
mkdir -p /opt/aiklog/data/themes/verdant
# 上传 server/data/themes/verdant/{ssr.css,manifest.json} 到该目录即可（按 mtime 热生效）
```

生效范围：`/blog`（列表页）、`/{slug}`（文章页），含主题下拉自动出现。

### 3.3 预览与切换

| 目的 | 方式 |
|---|---|
| SSR 列表页预览 | `/blog?theme=verdant` |
| SSR 文章页预览 | `/{slug}?theme=verdant` |
| SPA 公开页 | `/app#/blog?view=public`（页头主题切换器可切） |
| 设为站点主题 | 控制台「博客管理 → 站点设置 → 主题」选「青野 Verdant」 |

---

## 4. 契约遵循

- 数据全部 `inject('themeContext')`，**组件不接收 props，不自行取接口**；
- 只使用契约字段 `token / path / preview / file.{name,slug,updated_at,size}`，**未使用任何契约外字段**（无 `views / likes / comments / cover / summary / readTime / comnum`）；
- 链接一律 `ctx.postUrl(post)`（SPA 文章页），分享/SEO 用 `ctx.postSsrUrl(post)`（SSR `/{slug}`）；**未手拼 `#/p/`、`#/post/`**；
- **不重排 `posts`**：默认保持系统「置顶优先 + 更新时间倒序」，排序下拉仅在读者显式操作时生效；
- 站名用 `<span>`/`<div>`，不占用 `<h1>`；
- 标签云 `v-if="tags.length"` + `{{ t.name }}` + 非链接 `<span>`（系统层 `tags` 当前恒空，空时整块隐藏）；
- **页内跳转一律 `button` + `scrollIntoView()`**：全主题无 `href="#…"`、无 `:href="'#' + x"`、无 `location.hash` 赋值（宿主为 hash 路由）；
- `file.author` 为系统侧待透出字段：作者页在字段缺失时**如实提示并降级为全部文章**，不伪造匹配；
- 文案只描述可证事实：首篇标注为「**头条**（排在最前的一篇）」，侧栏为「**最新更新**」，无「热门 / 精选 / 排行」类不可验证文案。

---

## 5. 设计令牌（`--th-*`）

与 `manifest.js` 的 `tokens` 台账**逐项一致**（自检第 2 项卡过）。

| 令牌 | 用途 | 值 |
|---|---|---|
| `--th-ink` | 正文色（深墨绿） | `#12261a` |
| `--th-ink-2` | 次要文字 | `#4c6656` |
| `--th-ink-3` | 弱化文字 | `#8ca494` |
| `--th-paper` | 页面底色（暖白） | `#fbfcf7` |
| `--th-card` | 卡片底色 | `#ffffff` |
| `--th-line` | 描边与分隔线 | `#e3ebd8` |
| `--th-green` | 主强调（森林绿） | `#15803d` |
| `--th-green-deep` | 强调深阶 | `#0f5f2e` |
| `--th-mint` | 辅助（薄荷） | `#86efac` |
| `--th-leaf` | 浅叶色底 | `#e7f5e1` |
| `--th-sun` | 点缀（琥珀） | `#f5b942` |
| `--th-r-sm` | 小圆角 | `12px` |
| `--th-r` | 常规圆角 | `18px` |
| `--th-r-lg` | 大圆角（卡片） | `26px` |
| `--th-font-d` | 标题字体 | 无衬线系统栈 |
| `--th-font-b` | 正文字体 | 无衬线系统栈 |

SSR 侧另用规范附录 A 的 8 个变量（`--ink / --ink2 / --ink3 / --paper / --line / --jade / --card / --font-d`），已逐项映射到上表同名色值。

---

## 6. 自测记录

### 6.1 机械自检（`tools/theme-lint.sh`）

```bash
cd web/src/themes/verdant
bash theme-lint.sh vd-      # 前缀可省略（自动推断）；退出码 0 = 通过
echo $?
```

运行结果（2026-09-16）：

```
[1/6] 类名交叉比对      悬空类 [OK] 无 · 死 CSS [OK] 无
[2/6] manifest.tokens  漏报 [OK] 无 · 虚报 [OK] 无
[3/6] hash 路由锚点      [OK] 无
[4/6] 高危文案词         [OK] 无
[5/6] 契约外字段         [OK] 无
[6/6] 文章页视图隔离     声明 entries.post 且存在 post.css [OK] · style.css 无文章根选择器 [OK]
== 结论 == [OK] 自动检查项全部通过          EXIT=0
```

### 6.2 构建验证

```
vite build  →  ✓ built in 5.05s（零错误零警告）

VerdantView-DLRwPQrD.js          10.90 KB │ gzip  4.25 KB
VerdantCard-R3KJsaia.js           1.25 KB │ gzip
VerdantCatView-Dgqx1TsP.js        2.53 KB │ gzip
VerdantAuthorView-Dt3jmBVK.js     2.42 KB │ gzip
VerdantArchiveView-BhYLAAAX.js    2.58 KB │ gzip
VerdantSearchView-D0M-2lfO.js     2.90 KB │ gzip
VerdantFoot-5aPB6qDK.js           2.61 KB │ gzip
index-DdJ2_f_6.js（注册表，含 VerdantPostView）
```

### 6.3 作用域与注册核验

| 项 | 结果 |
|---|---|
| `.th-verdant` 选择器数（style.css 作用域） | **287** |
| `.th-verdant.th-view-post` 选择器数（post.css 作用域） | **88** |
| 产物中主题 id `verdant` / 标题 `青野 Verdant` | ✅ 均在注册 chunk 中 |
| 令牌落地抽查 | `--th-green: #15803d` ✅ |
| 文章页选择器形态抽查 | `.th-verdant.th-view-post .vd-post-h1` ✅ |

### 6.4 人工核对项（脚本盲区）

- 动态 `:class` 绑定共 5 处，逐个核对均有对应规则：`.vd-chipbtn.on`、`.vd-pagenum.on`、`.vd-card-art.tone1~4`、`.vd-feat-art.tone1~4`、`.vd-toc-item.sub`；
- grid/flex 子项 `min-width: 0` 已逐一检查（`.vd-list-col` / `.vd-aside` / `.vd-card` / `.vd-post-main` / `.vd-post-aside` / `.vd-sb` / `.vd-orb` 等）；
- 移动端断点：`1040px`（两栏降单栏、侧栏取消 sticky）、`720px`（网格降单列、导航精简）。

---

## 7. 已知限制

1. **未在真实运行环境完成端到端截图**。本机无 Go 工具链，无法本地构建后端二进制；`design/` 下的两张图是**设计稿基线**（浏览器直开 `design-verdant.html` 可比对），**不是主题运行截图**。建议在部署机完成 §3.1 后，用 `/blog?theme=verdant` 与 `/app#/blog?view=public` 各截一张并排对照。
2. **作者页依赖系统侧待透出字段** `posts[].file.author`（规范 §10-10）；未透出时该页降级为「全部公开文章」并给出明确提示。
3. **标签数据未实现**（规范 §4.6）：`ctx.tags` 恒为空数组，侧栏标签区块自动隐藏，系统层实现后无需改组件。
4. **分类 / 作者 / 归档 / 搜索内页的系统路由为二期**（规范 §10）：组件已按 §4.4–§4.8 契约实现，系统补齐路由与 `ctx.page` 注入后自动生效；当前可经 hash 参数预览。
5. **文章页链接行为**：`ctx.postUrl()` 在当前系统实现下优先返回 `/{slug}`（SPA 列表点文章会跳 SSR 静态页），属系统侧已知项；主题侧坚持使用 `ctx.postUrl`，系统修复后全站自动生效。
6. 主题**未实现 AI 问答**（规范 §7.1 属可选能力），侧栏以 RSS 订阅引导替代。

---

## 8. 版本记录

| 版本 | 日期 | 变更 |
|---|---|---|
| **1.0.0** | 2026-09-16 | 首版交付：列表页（Hero / 头条 / 分类筛选 / 关键词检索 / 排序 / 分页 / 侧栏）+ 文章页（目录 / 上下篇 / 同类文章 / 接着读 / 评论插件槽）+ 分类 / 作者 / 归档 / 搜索四内页；`ssr.css` 覆盖公网列表页与文章页；自检 6 项全过。 |

---

## 9. 目录树

```
verdant-theme-1.0.0/
├── README.md
├── web/src/themes/verdant/
│   ├── manifest.js  index.js  helpers.js
│   ├── VerdantView.vue      VerdantPostView.vue
│   ├── VerdantCatView.vue   VerdantAuthorView.vue
│   ├── VerdantArchiveView.vue  VerdantSearchView.vue
│   ├── VerdantHead.vue  VerdantFoot.vue  VerdantCard.vue  VerdantSide.vue
│   ├── style.css            # 列表 + 共享原子
│   └── post.css             # 文章页专属（视图隔离）
├── server/data/themes/verdant/
│   ├── ssr.css
│   └── manifest.json
├── design/
│   ├── design-verdant.html
│   ├── 对照-桌面-1440.png
│   └── 对照-移动-390.png
└── tools/theme-lint.sh
```
